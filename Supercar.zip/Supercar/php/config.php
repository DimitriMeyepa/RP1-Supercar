<?php
$host = 'localhost';      
$dbname = 'supercar';  
$username = 'root';        
$password = 'root';            

// Configuration de la connexion avec PDO 
try {
    // Création de la connexion PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    
    // Définir les attributs de PDO pour une gestion d'erreurs plus propre
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Si la connexion échoue, afficher un message d'erreur et arrêter le script
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>

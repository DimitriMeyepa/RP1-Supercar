<?php 
session_start(); 
include('php/config.php'); 
include('navbar.php'); 

// Vérifie si le client est connecté
if (!isset($_SESSION['client_id'])) {
    echo "<script>
        alert('Vous devez être connecté pour faire une demande d\'essai.');
        window.location.href = 'connexion.php';
    </script>";
    exit;
}

// Récupération des infos du client connecté
$client_id = $_SESSION['client_id'];
$clientQuery = "SELECT email_client, telephone_client, adresse_client FROM client WHERE id_client = :id";
$clientStmt = $pdo->prepare($clientQuery);
$clientStmt->bindParam(':id', $client_id);
$clientStmt->execute();
$clientInfo = $clientStmt->fetch(PDO::FETCH_ASSOC);

$email = $clientInfo['email_client'] ?? '';
$phone = $clientInfo['telephone_client'] ?? '';
$address = $clientInfo['adresse_client'] ?? '';

// Récupération des voitures et tri par marque
$voitureQuery = "SELECT car_name FROM voitures";
$voitureStmt = $pdo->query($voitureQuery);
$voitures = $voitureStmt->fetchAll(PDO::FETCH_ASSOC);

$voitureMap = [];

function normalizeBrand($brand) {
    $brand = strtolower($brand);
    if (strpos($brand, 'mercedes') !== false) return 'Mercedes';
    if (strpos($brand, 'porsche') !== false) return 'Porsche';
    if (strpos($brand, 'audi') !== false) return 'Audi';
    return ucfirst($brand); // fallback
}

foreach ($voitures as $v) {
    $fullName = $v['car_name'];
    $firstWord = explode(' ', $fullName)[0];
    $normalizedBrand = normalizeBrand($firstWord);
    $voitureMap[$normalizedBrand][] = $fullName;
}

// Préremplissage marque + modèle depuis URL
$car_name_from_url = $_GET['car_name'] ?? null;
$selected_brand = '';
$selected_model = '';

if ($car_name_from_url) {
    $selected_model = $car_name_from_url;
    $selected_brand = explode(' ', $car_name_from_url)[0]; 
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $carBrand = $_POST['carBrand'];
    $carReference = $_POST['carReference'];
    $testDate = $_POST['testDate'];

    $query = "SELECT id_client FROM client WHERE email_client = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client) {
        $id_client = $client['id_client'];
        $query = "INSERT INTO essai (date_essai, statut, id_client, car_name) 
                  VALUES (:date_essai, 'en_cours', :id_client, :car_name)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':date_essai', $testDate);
        $stmt->bindParam(':id_client', $id_client);
        $stmt->bindParam(':car_name', $carReference);

        if ($stmt->execute()) {
            echo "<script>
                alert('Demande d\\'essai envoyée avec succès !');
                window.location.href = 'index.php';
            </script>";
            exit();
        } else {
            $error_message = "Erreur lors de l'enregistrement de la demande d'essai.";
        }
    } else {
        $error_message = "Aucun client trouvé avec cet email.";
    }
}
?>


<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essai - Supercar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        body {
            background-image: url('../assets/img/fond-essai.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed; 
        }

        .container-custom {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 2rem;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 40px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            margin-top: 6rem;
        }

        .logo {
            display: block;
            margin: 0 auto 1rem;
            width: 80px;
        }

        @media (max-width: 768px) {
            .form-container {
                max-width: 90%;
            }
        }
    </style>
</head>
<body>

<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-2.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Faites votre demande d'essai</h1>
        </div>
    </div>
</div>

<div class="container container-custom">
    <div class="form-container">
        <img src="assets/logo1.png" class="logo" alt="Logo">
        <h2 class="text-center text-danger mb-3">DEMANDE D'ESSAI</h2>

        <?php if (!empty($error_message)) { ?>
            <div class="alert alert-danger text-center"><?= $error_message; ?></div>
        <?php } ?>

        <form action="" method="post">
            <div class="mb-3">
                <label for="email" class="form-label fw-bold text-dark">Email</label>
                <input type="email" class="form-control" id="email" name="email" required value="<?= htmlspecialchars($email) ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label fw-bold text-dark">Téléphone</label>
                <input type="tel" class="form-control" id="phone" name="phone" required value="<?= htmlspecialchars($phone) ?>">
            </div>
            <div class="mb-3">
                <label for="address" class="form-label fw-bold text-dark">Adresse</label>
                <input type="text" class="form-control" id="address" name="address" required value="<?= htmlspecialchars($address) ?>">
            </div>
            <div class="mb-3">
                <label for="carBrand" class="form-label fw-bold text-dark">Marque de la voiture</label>
                <select class="form-select" id="carBrand" name="carBrand" required>
                    <option value="">-- Choisissez une marque --</option>
                    <?php foreach (array_keys($voitureMap) as $brand): ?>
                        <option value="<?= htmlspecialchars($brand) ?>" <?= ($selected_brand === $brand ? 'selected' : '') ?>>
                            <?= htmlspecialchars($brand) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="carReference" class="form-label fw-bold text-dark">Modèle de la voiture</label>
                <select class="form-select" id="carReference" name="carReference" required>
                    <?php if ($selected_model): ?>
                        <option value="<?= htmlspecialchars($selected_model) ?>" selected><?= htmlspecialchars($selected_model) ?></option>
                    <?php else: ?>
                        <option value="">-- Sélectionnez un modèle --</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="testDate" class="form-label fw-bold text-dark">Date d’essai</label>
                <input type="text" class="form-control" id="testDate" name="testDate" placeholder="Choisissez une date et une heure" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-danger btn-lg">Valider</button>
            </div>
        </form>
    </div>
</div>

<script>
    const voitureMap = <?= json_encode($voitureMap); ?>;
    document.addEventListener('DOMContentLoaded', function () {
        const brandSelect = document.getElementById('carBrand');
        const modelSelect = document.getElementById('carReference');

        function updateModeles() {
            const selectedBrand = brandSelect.value;
            const modeles = voitureMap[selectedBrand] || [];

            modelSelect.innerHTML = '';
            if (modeles.length === 0) {
                modelSelect.innerHTML = '<option>Aucun modèle disponible</option>';
                return;
            }

            modeles.forEach(modele => {
                const option = document.createElement('option');
                option.value = modele;
                option.textContent = modele;
                modelSelect.appendChild(option);
            });

            const preselectedModel = "<?= isset($selected_model) ? addslashes($selected_model) : '' ?>";
            if (preselectedModel) {
                const match = Array.from(modelSelect.options).find(opt => opt.value === preselectedModel);
                if (match) match.selected = true;
            }
        }

        brandSelect.addEventListener('change', updateModeles);
        updateModeles();
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    flatpickr("#testDate", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    minDate: "today",
    minTime: "09:00",
    maxTime: "20:30",
    time_24hr: true
});
</script>

<?php include('footer.php'); ?>
</body>
</html>

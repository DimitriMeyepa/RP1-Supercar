<?php
include('config/config.php');
include('includes/navbar.php');

// Traitement du formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_name = $_POST['car_name'];
    $fuel_type = $_POST['fuel_type'];
    $year = $_POST['year'];
    $car_transmission = $_POST['car_transmission'];
    $car_km = $_POST['car_km'];
    $car_price = $_POST['car_price'];
    $car_status = $_POST['car_status'];
    $engine_capacity = $_POST['engine_capacity']; 

    // Génération automatique de car_ref
    $car_ref = 'CAR-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));

    $car_image = '';

    // Vérifier si une image est uploadée
    if (!empty($_FILES['car_image']['name'])) {
        $car_image_name = basename($_FILES['car_image']['name']);
        $car_image_path = 'assets/list/' . $car_image_name;

        $image_file_type = strtolower(pathinfo($car_image_path, PATHINFO_EXTENSION));
        $valid_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($image_file_type, $valid_types)) {
            $admin_path = __DIR__ . '/assets/list/' . $car_image_name;
            if (move_uploaded_file($_FILES['car_image']['tmp_name'], $admin_path)) {
                synchroniserImage($car_image_name); // synchroniser avec supercar
                $car_image = 'assets/list/' . $car_image_name;
            } else {
                die("Erreur lors de l'upload de l'image.");
            }
        } else {
            die("Type d'image invalide.");
        }
    }

    // Insertion dans la base de données
    $sql = "INSERT INTO voitures (car_ref, car_name, fuel_type, year, car_transmission, car_km, car_price, car_status, car_image, engine_capacity)
        VALUES (:car_ref, :car_name, :fuel_type, :year, :car_transmission, :car_km, :car_price, :car_status, :car_image, :engine_capacity)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'car_ref' => $car_ref,
        'car_name' => $car_name,
        'fuel_type' => $fuel_type,
        'year' => $year,
        'car_transmission' => $car_transmission,
        'car_km' => $car_km,
        'car_price' => $car_price,
        'car_status' => $car_status,
        'car_image' => $car_image,
        'engine_capacity' => $engine_capacity
    ]);

    header('Location: voitures.php');
    exit;
}

// Fonction pour synchroniser l'image vers le dossier client
function synchroniserImage($imageName)
{
    $adminDir = __DIR__ . '/assets/list/'; 
    $clientDir = __DIR__ . '/../supercar/supercar-client/assets/list/'; 


    if (!file_exists($clientDir)) {
        if (!mkdir($clientDir, 0777, true)) {
            die("Impossible de créer le dossier client pour les images.");
        }
    }

}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            border: 2px solid #8e1616; /* Cadre rouge */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Légère ombre */
        }
        .form-control {
            border-radius: 0;
        }
        .btn-success {
            background-color: #8e1616;
            border: none;
        }
        .btn-secondary {
            background-color: #f8f9fa;
            border: none;
            color: #8e1616;
        }
        .navbar {
            margin-bottom: 30px;
        }
        h2 {
            color: #8e1616;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">Ajouter une Voiture</h2>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="car_name">Nom de la voiture</label>
            <input type="text" class="form-control" id="car_name" name="car_name" required>
        </div>

        <div class="form-group">
            <label for="fuel_type">Type de carburant</label>
            <select class="form-control" id="fuel_type" name="fuel_type" required>
                <option value="">-- Sélectionner --</option>
                <option value="Essence">Essence</option>
                <option value="Diesel">Diesel</option>
                <option value="Hybride">Hybride</option>
                <option value="Électrique">Électrique</option>
            </select>
        </div>

        <div class="form-group">
            <label for="year">Année</label>
            <input type="number" class="form-control" id="year" name="year" required>
        </div>

        <div class="form-group">
            <label for="car_transmission">Transmission</label>
            <select class="form-control" id="car_transmission" name="car_transmission" required>
                <option value="">-- Sélectionner --</option>
                <option value="Manuelle">Manuelle</option>
                <option value="Automatique">Automatique</option>
            </select>
        </div>

        <div class="form-group">
            <label for="car_km">Kilométrage</label>
            <input type="number" class="form-control" id="car_km" name="car_km" required>
        </div>

        <div class="form-group">
            <label for="car_price">Prix</label>
            <input type="number" class="form-control" id="car_price" name="car_price" required>
        </div>

        <div class="form-group">
            <label for="car_status">Statut</label>
            <select class="form-control" id="car_status" name="car_status" required>
                <option value="">-- Sélectionner --</option>
                <option value="Disponible">Disponible</option>
                <option value="Vendu">Vendu</option>
            </select>
        </div>

        <div class="form-group">
            <label for="car_image">Image de la voiture</label>
            <input type="file" class="form-control" id="car_image" name="car_image" accept="image/*">
        </div>

        <div class="form-group">
            <label for="engine_capacity">Cylindrée (engine capacity)</label>
            <input type="text" class="form-control" id="engine_capacity" name="engine_capacity" required>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-success">Ajouter la voiture</button>
            <a href="voitures.php" class="btn btn-secondary">Retour</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

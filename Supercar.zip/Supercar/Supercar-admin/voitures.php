<?php
include('config/config.php');
include('includes/navbar.php');
$search = $_GET['search'] ?? '';

// Requête SQL
$sql = "SELECT * FROM voitures WHERE car_name LIKE :search OR fuel_type LIKE :search";
$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => '%' . $search . '%']);
$voitures = $stmt->fetchAll();  // Toutes les voitures qui correspondent
?>

<!doctype html>
<html lang="fr">

<head>
    <title>Voitures - Supercar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Google Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />

    <!-- Styles communs pour toutes les pages -->
    <link rel="stylesheet" href="css/styles.css">

    <!-- Style spécifique à la page -->
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        h1.display-5 {
        color: #333;
        text-align: center;
        padding-top: 30px;
        margin-bottom: 30px;
      
        }

        .voitures-container .card {
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            border: none;
            transition: transform 0.2s ease;
            height: 100%;
        }

        .voitures-container .card:hover {
            transform: translateY(-5px);
        }

        .voitures-container .card img {
            height: 200px;
            object-fit: cover;
        }

        .voitures-container .row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .col-md-4 {
            flex: 1 0 30%;
        }

        @media screen and (max-width: 768px) {
            .voitures-container .card img {
                height: 180px;
            }

            .col-md-4 {
                flex: 1 0 100%;
            }
        }

        .input-group {
            margin: 30px auto;
            max-width: 600px;
            display: flex;
            justify-content: center;
        }

        .input-group .form-control,
        .input-group .btn {
            border-radius: 0.25rem;
        }

        .section-heading {
            margin-bottom: 20px;
            font-weight: 700;
        }

        .site-section {
            padding-top: 2rem;  
        }

        .btn-primary {
            background-color: #8E1616;
            border-color: #8E1616;
        }

        .btn-primary:hover {
            background-color: #a01b1b;
            border-color: #a01b1b;
        }

        .btn-warning {
            background-color: #8E1616;
            border-color: #8E1616;
            color: #fff;
        }

        .btn-warning:hover {
            background-color: #a01b1b;
            border-color: #a01b1b;
        }

        .btn-danger {
            background-color: #000;
            border-color: #000;
            color: #fff;
        }

        .btn-danger:hover {
            background-color: #333;
            border-color: #333;
        }

        .material-symbols-outlined {
            vertical-align: middle;
            font-size: 20px;
        }
    </style>
</head>

<body>
    <div class="site-section bg-white animated slideInUp">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h1 class="Display-5"><strong>Liste des voitures</strong></h1>
                    
                </div>
            </div>

            <!-- Formulaire de recherche -->
            <form class="input-group" method="get" action="voitures.php">
                <input type="text" class="form-control" name="search" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="basic-addon2" id="search" value="<?= htmlspecialchars($search) ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Rechercher</button>
                </div>
            </form>

            <!-- Liste de voitures -->
            <div class="container-fluid voitures-container mt-5">
                <div class="add-btn">
                    <a href="ajouter-voiture.php" class="btn btn-primary" title="Ajouter une nouvelle voiture" aria-label="Ajouter">
                        <span class="material-symbols-outlined">add_circle</span>
                    </a>
                </div><br>
                <div class="row justify-content-center">
                    <?php if (count($voitures) > 0): ?>
                        <?php foreach ($voitures as $voiture): ?>
                            <div class="col-md-4 col-sm-6 d-flex">
                                <div class="card w-100">
                                    <img src="<?= htmlspecialchars($voiture['car_image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($voiture['car_name']) ?>">
                                    <div class="card-body">
                                        <p class="text-muted mb-1 text-start"><?= htmlspecialchars($voiture['car_status']) ?></p>
                                        <h5 class="card-title fw-bold"><?= htmlspecialchars($voiture['car_name']) ?></h5>
                                        <ul class="list-unstyled d-flex flex-wrap gap-2">
                                            <li class="d-flex align-items-center me-3">
                                                <span class="material-symbols-outlined me-1">auto_transmission</span> <?= htmlspecialchars($voiture['car_transmission']) ?>
                                            </li>
                                            <li class="d-flex align-items-center me-3">
                                                <span class="material-symbols-outlined me-1">local_gas_station</span> <?= htmlspecialchars($voiture['fuel_type']) ?>
                                            </li>
                                            <li class="d-flex align-items-center me-3">
                                                <span class="material-symbols-outlined me-1">calendar_month</span> <?= htmlspecialchars($voiture['year']) ?>
                                            </li>
                                            <li class="d-flex align-items-center me-3">
                                                <span class="material-symbols-outlined me-1">swap_driving_apps_wheel</span> <?= number_format($voiture['car_km'], 0, ',', ' ') ?> km
                                            </li>
                                        </ul>
                                        <div class="d-flex justify-content-between mt-3">
                                            <a href="modifier-voiture.php?action=edit&id=<?= $voiture['id'] ?>" class="btn btn-warning" title="Modifier" aria-label="Modifier">
                                                <span class="material-symbols-outlined">edit</span>
                                            </a>
                                            <a href="supprimer-voiture.php?action=delete&id=<?= $voiture['id'] ?>" class="btn btn-danger" title="Supprimer" aria-label="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette voiture ?')">
                                                <span class="material-symbols-outlined">delete</span>
                                            </a>
                                        </div>
                                    </div>
                                    <hr class="ligne-card">
                                    <div class="card-body d-flex justify-content-between align-items-center">
                                        <p class="fw-bold m-0"><?= number_format($voiture['car_price'], 2, ',', ' ') ?> MUR</p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-center">Aucune voiture trouvée.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- JS Scripts -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
</body>

</html>

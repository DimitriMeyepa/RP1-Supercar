<?php
include('config/config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Optionnel : récupérer l'image pour la supprimer aussi
    $stmt = $pdo->prepare("SELECT car_image FROM voitures WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $voiture = $stmt->fetch();

    if ($voiture) {
        // Supprimer l'image dans les 2 dossiers si elle existe
        if (!empty($voiture['car_image'])) {
            $imageName = basename($voiture['car_image']);
            $adminPath = __DIR__ . '/assets/list/' . $imageName;
            $clientPath = __DIR__ . '/../supercar/assets/list/' . $imageName;

            if (file_exists($adminPath)) {
                unlink($adminPath);
            }

            if (file_exists($clientPath)) {
                unlink($clientPath);
            }
        }

        // Supprimer la voiture de la base
        $stmt = $pdo->prepare("DELETE FROM voitures WHERE id = :id");
        $stmt->execute(['id' => $id]);

        header('Location: voitures.php?deleted=1');
        exit;
    } else {
        echo "Voiture introuvable.";
    }
} else {
    echo "ID non spécifié.";
}
?>

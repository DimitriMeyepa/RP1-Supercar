<?php
require_once 'config/config.php';
include('includes/navbar.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $service_name = $_POST['service'];
  $title = $_POST['title'];
  $description = $_POST['description'];

  // Liste des icônes possibles (tu peux en ajouter d'autres ici)
  $default_icons = ['fa-car-side', 'fa-car', 'fa-cog'];
  $icon = $default_icons[array_rand($default_icons)]; // Choisir une icône aléatoire

  // Gestion image
  $uploadDir = 'img/';
  $imageName = time() . '_' . basename($_FILES['image']['name']);
  $imagePath = $uploadDir . $imageName;

  if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
    synchroniserImage($imagePath);
  } else {
    die("Erreur lors du téléchargement de l'image.");
  }

  // Insertion en base de données
  $stmt = $pdo->prepare("INSERT INTO services (service, title, description, image, icon) VALUES (:service, :title, :description, :image, :icon)");
  $stmt->execute([
    ':service' => $service_name,
    ':title' => $title,
    ':description' => $description,
    ':image' => $imagePath,
    ':icon' => $icon
  ]);

  header("Location: service.php");
  exit();
}

// Fonction de synchronisation
function synchroniserImage($imagePath)
{
  $filename = basename($imagePath);
  $adminPath = __DIR__ . '/img/' . $filename;
  $clientPath = __DIR__ . '/../supercar/img/' . $filename;

  if (file_exists($adminPath)) {
    if (!copy($adminPath, $clientPath)) {
      echo "Erreur lors de la synchronisation de l'image.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <title>Ajouter un Service</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
     
      font-family: Arial, sans-serif;
    }

    .container {
      width: 90%;
      max-width: 1000px;
      margin-top: 5rem;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
      color: #c0392b;
    }

    .btn-primary {
      background-color: #c0392b;
      border-color: #c0392b;
    }

    .btn-primary:hover {
      background-color: #a02a1b;
      border-color: #900;
    }
  </style>
</head>

<body>

  <div class="container">
    <h1 class="mb-4">Ajouter un Nouveau Service</h1>
    <form action="ajouter_service.php" method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="service" class="form-label">Nom du Service</label>
        <input type="text" class="form-control" id="service" name="service" required>
      </div>

      <div class="mb-3">
        <label for="title" class="form-label">Titre</label>
        <input type="text" class="form-control" id="title" name="title" required>
      </div>

      <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
      </div>

      <div class="mb-3">
        <label for="image" class="form-label">Image (jpg, png...)</label>
        <input class="form-control" type="file" id="image" name="image" accept="image/*" required>
      </div>

      <button type="submit" class="btn btn-primary">Ajouter le service</button>
      <a href="service.php" class="btn btn-secondary ms-2">Annuler</a>
    </form>
  </div>

  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
require 'config/config.php'; 
include('includes/navbar.php');

// Mise à jour du statut
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_essai'], $_POST['statut'])) {
    $id_essai = $_POST['id_essai'];
    $statut = $_POST['statut'];
    $update_sql = "UPDATE essai SET statut = ? WHERE id_essai = ?";
    $stmt_update = $pdo->prepare($update_sql);
    $stmt_update->execute([$statut, $id_essai]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Récupération des essais avec infos client
$sql = "SELECT essai.*, client.id_client, CONCAT(client.nom_client, ' ', client.prenom_client) AS nom_complet 
        FROM essai 
        JOIN client ON essai.id_client = client.id_client 
        ORDER BY date_essai DESC";
$stmt = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Visualiser les essais</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>

        body {
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         background-color: #f4f7fc;
         }
        h1.display-5 {
        color: #333;
        text-align: center;
       
        
        }
        .table th {
            background-color: #fff;
            border-radius: 2px;
            color: #8E1616;
        }
        .badge {
             display: inline-block;
             padding: 0.5em 0.75em;
             font-size: 0.9em;
             font-weight: 500;
             border-radius: 0.5rem;
             color: #fff;
            }

        .badge-en-cours {
            background-color: #ffbf00ff;
        }
        .badge-accepte {
            background-color: #01ff1aff;
        }
        .badge-termine {
            background-color: #6c757d;
        }
        .badge-refuse {
         background-color: #dc3545; 
         color: white;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="display-5"> <strong>Liste des essais</strong></h1>
        <table class="table table-bordered text-center rounded-1">
            <tr>
                <th>ID Essai</th>
                <th>Date Essai</th>
                <th>Statut</th>
                <th>Marque</th>
                <th>ID Client</th>
                <th>Nom Client</th>
                <th>Modifier Statut</th>
            </tr>
            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><?= $row['id_essai']; ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($row['date_essai'])); ?></td>
                    <td>
                       <?php
                            if ($row['statut'] == 'en_cours') {
                                echo '<span class="badge badge-en-cours">En cours</span>';
                            } elseif ($row['statut'] == 'accepte') {
                                echo '<span class="badge badge-accepte">Accepté</span>';
                            } elseif ($row['statut'] == 'termine') {
                                echo '<span class="badge badge-termine">Terminé</span>';
                            } elseif ($row['statut'] == 'refuse') {
                                echo '<span class="badge badge-refuse">Refusé</span>';
                            }
                        ?>
                    </td>
                    <td><?= htmlspecialchars($row['car_name']); ?></td>
                    <td><?= $row['id_client']; ?></td>
                    <td><?= htmlspecialchars($row['nom_complet']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="id_essai" value="<?= $row['id_essai']; ?>">
                           <select name="statut" class="form-select d-inline w-auto">
                                <option value="en_cours" <?= $row['statut'] == 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                                <option value="accepte" <?= $row['statut'] == 'accepte' ? 'selected' : ''; ?>>Accepté</option>
                                <option value="termine" <?= $row['statut'] == 'termine' ? 'selected' : ''; ?>>Terminé</option>
                                <option value="refuse" <?= $row['statut'] == 'refuse' ? 'selected' : ''; ?>>Refusé</option>
                            </select>
                            <button type="submit" class="btn btn-danger btn-sm">Valider</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

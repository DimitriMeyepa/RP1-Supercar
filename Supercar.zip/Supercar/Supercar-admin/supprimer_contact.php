<?php
require 'config/config.php';
include('includes/navbar.php');

if (!isset($_GET['id'])) {
    exit('ID manquant.');
}

$id = $_GET['id'];

$stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
$stmt->execute([$id]);

header("Location: contact.php");
exit;

<?php
require 'config/config.php';
include('includes/navbar.php');

if (!isset($_GET['id'])) {
    exit('ID manquant.');
}

$id = $_GET['id'];
$message = $pdo->prepare("SELECT * FROM contact_messages WHERE id = ?");
$message->execute([$id]);
$data = $message->fetch();

if (!$data) {
    exit("Message non trouvé.");
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE contact_messages SET nom = ?, email = ?, telephone = ? WHERE id = ?");
    $stmt->execute([
        $_POST['nom'],
        $_POST['email'],
        $_POST['telephone'],
        $id
    ]);
    echo "<script>alert('Informations modifiées avec succès'); window.location.href='admin_page.php';</script>";
}
?>

<!doctype html>
<html lang="fr">
<head>
    <title>Modifier Message - Supercar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            border: 2px solid #8e1616;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-control {
            border-radius: 0;
            margin-bottom: 1rem;
        }
        .btn-primary {
            background-color: #8e1616;
            border: none;
        }
        .btn-secondary {
            background-color: #f8f9fa;
            border: none;
            color: #8e1616;
        }
        h2 {
            color: #8e1616;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center mb-4">Modifier les infos du message</h2>

        <form method="POST">
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" value="<?= htmlspecialchars($data['nom']) ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Adresse e-mail</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
            </div>

            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" value="<?= htmlspecialchars($data['telephone']) ?>" required>
            </div>

            <div class="form-group">
                <label for="message">Message (non modifiable)</label>
                <textarea class="form-control" id="message" rows="5" readonly style="background-color: #f4f4f4;"><?= htmlspecialchars($data['message']) ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Mettre à jour</button>
            <a href="contact.php" class="btn btn-secondary">Retour</a>
        </form>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

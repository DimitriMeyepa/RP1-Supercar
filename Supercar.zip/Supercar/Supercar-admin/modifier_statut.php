<?php
require 'config/config.php';

// Vérifier si l'ID de l'essai et le nouveau statut sont envoyés via POST
if (isset($_POST['id_essai']) && isset($_POST['nouveau_statut'])) {
    $id_essai = $_POST['id_essai'];
    $nouveau_statut = $_POST['nouveau_statut'];

    // Préparer la requête pour mettre à jour le statut de l'essai
    $sql = "UPDATE essai SET statut = :statut WHERE id_essai = :id_essai";

    try {
        // Préparer et exécuter la requête SQL
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':statut' => $nouveau_statut,
            ':id_essai' => $id_essai
        ]);

        // Si l'exécution réussit, rediriger vers essai.php avec un message de succès
        header('Location: essai.php?success=1');
        exit; // Important pour éviter que le script continue après la redirection

    } catch (PDOException $e) {
        // En cas d'erreur, afficher un message d'erreur
        echo "Erreur : " . $e->getMessage();
    }
} else {
    // Si les données ne sont pas envoyées, rediriger vers essai.php sans modification
    header('Location: essai.php');
    exit;
}
?>


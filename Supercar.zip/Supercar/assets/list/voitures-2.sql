-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 05, 2025 at 02:53 PM
-- Server version: 8.0.35
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supercar`
--

-- --------------------------------------------------------

--
-- Table structure for table `voitures`
--

CREATE TABLE `voitures` (
  `id` int NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `carburant` varchar(50) DEFAULT NULL,
  `transmission` varchar(50) DEFAULT NULL,
  `annee` int DEFAULT NULL,
  `kilometrage` int DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  `statut` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `voitures`
--

INSERT INTO `voitures` (`id`, `nom`, `image`, `carburant`, `transmission`, `annee`, `kilometrage`, `prix`, `statut`) VALUES
(1, 'Mercedes-Benz C-Class 2018', 'MBZ-CC-2018.jpg', 'Essence', 'Automatique', 2018, 15000, 950000.00, 'Disponible'),
(2, 'Mercedes-Benz S63 AMG', 'MB-S63-AMG-001.jpg', 'Essence', 'Automatique', 2022, 15000, 12500000.00, 'Disponible'),
(3, 'Mercedes-Benz Cabriolet', 'MB-Cabriolet-002.jpg', 'Essence', 'Automatique', 2021, 20000, 9500000.00, 'Disponible'),
(4, 'Mercedes-Benz GLE 2021', 'MB-GLE-003.jpg', 'Diesel', 'Automatique', 2021, 30000, 8500000.00, 'Disponible'),
(5, 'Mercedes-AMG GT 63', 'MB-GT63-004.jpg', 'Essence', 'Automatique', 2023, 5000, 15000000.00, 'Disponible'),
(6, 'Mercedes-Benz Classe G', 'MB-G-Class-005.jpg', 'Diesel', 'Automatique', 2022, 10000, 17500000.00, 'Disponible'),
(7, 'Porsche 718 Cayman', '718_cayman_porsche.jpg', 'Essence', 'Automatique', 2025, 0, 2499999.00, 'Disponible'),
(8, 'Porsche 911 Carrera 4S', '911_carrera_4s.jpg', 'Essence', 'Manuelle', 2023, 15000, 3499999.00, 'Disponible'),
(9, 'Porsche Panamera', 'panamera.jpg', 'Essence', 'Automatique', 2025, 0, 4499999.00, 'Vendu'),
(10, 'Porsche Macan', 'macan.jpg', 'Diesel', 'Automatique', 2022, 25000, 3299999.00, 'Disponible'),
(11, 'Porsche Cayenne Turbo', 'porsche_cayenne_turbo.jpg', 'Essence', 'Automatique', 2025, 0, 5499999.00, 'Vendu'),
(12, 'Porsche 911 GT3', 'porsche-gt3.jpg', 'Essence', 'Manuelle', 2020, 30000, 6399999.00, 'Disponible'),
(13, 'Audi - A6', 'A6-001.jpg', 'Essence', 'Automatique', 2020, 25000, 35000.00, 'Disponible'),
(14, 'Audi - A7', 'A7-001.jpg', 'Diesel', 'Manuelle', 2019, 30000, 42000.00, 'Vendu'),
(15, 'Audi - Q7', 'Q7-001.jpg', 'Essence', 'Automatique', 2021, 20000, 45000.00, 'Disponible'),
(16, 'Audi - Q8', 'Q8-001.jpg', 'Essence', 'Automatique', 2022, 15000, 65000.00, 'Disponible'),
(17, 'Audi - R8', 'R8-001.jpg', 'Essence', 'Automatique', 2021, 10000, 120000.00, 'Vendu'),
(18, 'Audi - RS6', 'RS6-001.jpg', 'Diesel', 'Manuelle', 2023, 5000, 95000.00, 'Vendu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `voitures`
--
ALTER TABLE `voitures`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `voitures`
--
ALTER TABLE `voitures`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

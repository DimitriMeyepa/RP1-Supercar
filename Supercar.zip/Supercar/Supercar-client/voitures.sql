-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 05, 2025 at 02:20 PM
-- Server version: 8.0.35
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supercar`
--

-- --------------------------------------------------------

--
-- Table structure for table `voitures`
--

CREATE TABLE `voitures` (
  `id` int NOT NULL,
  `car_name` varchar(255) NOT NULL,
  `car_ref` varchar(100) NOT NULL,
  `car_status` varchar(50) NOT NULL,
  `car_transmission` varchar(50) NOT NULL,
  `fuel_type` varchar(50) NOT NULL,
  `engine_capacity` decimal(5,2) NOT NULL,
  `year` int NOT NULL,
  `car_km` int NOT NULL,
  `car_price` decimal(10,2) NOT NULL,
  `image_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `voitures`
--

INSERT INTO `voitures` (`id`, `car_name`, `car_ref`, `car_status`, `car_transmission`, `fuel_type`, `engine_capacity`, `year`, `car_km`, `car_price`, `image_id`) VALUES
(19, 'Mercedes-Benz C-Class 2018', 'MBZ-CC-2018', 'Disponible', 'Automatique', 'Essence', 2.00, 2024, 15000, 950000.00, NULL),
(20, 'Mercedes-Benz S63 AMG', 'MB-S63-AMG-001', 'Disponible', 'Automatique', 'Essence', 4.00, 2022, 15000, 12500000.00, NULL),
(21, 'Mercedes-Benz Cabriolet', 'MB-Cabriolet-002', 'Disponible', 'Automatique', 'Essence', 3.00, 2021, 20000, 9500000.00, NULL),
(22, 'Mercedes-Benz GLE 2021', 'MB-GLE-003', 'Disponible', 'Automatique', 'Diesel', 2.90, 2021, 30000, 8500000.00, NULL),
(23, 'Mercedes-AMG GT 63', 'MB-GT63-004', 'Disponible', 'Automatique', 'Essence', 4.00, 2023, 5000, 15000000.00, NULL),
(24, 'Mercedes-Benz Classe G', 'MB-G-Class-005', 'Disponible', 'Automatique', 'Diesel', 3.00, 2022, 10000, 17500000.00, NULL),
(25, 'Porsche 718 Cayman', '718_cayman_porsche', 'disponible', 'Automatique', 'Essence', 2.50, 2025, 0, 2499999.00, NULL),
(26, 'Porsche 911 Carrera 4S', '911_carrera_4s', 'disponible', 'Manuelle', 'Essence', 3.00, 2023, 15000, 3499999.00, NULL),
(27, 'Porsche Panamera', 'panamera', 'vendu', 'Automatique', 'Essence', 3.60, 2025, 0, 4499999.00, NULL),
(28, 'Porsche Macan', 'macan', 'disponible', 'Automatique', 'Diesel', 2.00, 2022, 25000, 3299999.00, NULL),
(29, 'Porsche Cayenne Turbo', 'porsche_cayenne_turbo', 'vendu', 'Automatique', 'Essence', 4.00, 2025, 0, 5499999.00, NULL),
(30, 'Porsche 911 GT3', 'porsche-gt3', 'disponible', 'Manuelle', 'Essence', 3.80, 2020, 30000, 6399999.00, NULL),
(37, 'Audi - A6', 'A6-001', 'Disponible', 'Automatique', 'Essence', 2.00, 2020, 25000, 35000.00, NULL),
(38, 'Audi - A7', 'A7-001', 'vendu', 'Manuelle', 'Diesel', 3.00, 2019, 30000, 42000.00, NULL),
(39, 'Audi - Q7', 'Q7-001', 'disponible', 'Automatique', 'Essence', 2.50, 2021, 20000, 45000.00, NULL),
(40, 'Audi - Q8', 'Q8-001', 'disponible', 'Automatique', 'Essence', 3.00, 2022, 15000, 65000.00, NULL),
(41, 'Audi - R8', 'R8-001', 'vendu', 'Automatique', 'Essence', 4.20, 2021, 10000, 120000.00, NULL),
(42, 'Audi - RS6', 'RS6-001', 'Vendu', 'Manuelle', 'Diesel', 3.50, 2023, 5000, 95000.00, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `voitures`
--
ALTER TABLE `voitures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_image_id` (`image_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `voitures`
--
ALTER TABLE `voitures`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `voitures`
--
ALTER TABLE `voitures`
  ADD CONSTRAINT `fk_image_id` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include('php/config.php');  
include('navbar.php');
$search = $_GET['search'] ?? '';  


$sql = "SELECT * FROM voitures WHERE car_name LIKE :search OR fuel_type LIKE :search";
$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => '%' . $search . '%']);
$voitures = $stmt->fetchAll();  
?>

<!doctype html>
<html lang="fr">

<head>
    <title>Voitures - Supercar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
        
        .voitures-container {
            margin-top: 20px;
        }

        .voiture-card {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .voiture-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 15px;
        }

        .card-title {
            font-weight: bold;
        }

        .input-group {
            max-width: 500px;
            margin: 0 auto 20px;
        }
    </style>
</head>

<body>
    <div class="container-fluid page-header mb-5 p-0 bgp-center" style="background-image: url(img/carousel-bg-3.jpg);">
        <div class="container-fluid page-header-inner py-5">
            <div class="container text-center">
                <h1 class="display-3 text-white mb-3 animated slideInDown">Voitures</h1>
            </div>
        </div>
    </div>

    <div class="site-section bg-white animated slideInUp">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <h2 class="section-heading"><strong>Liste de nos voitures</strong></h2>
                    <p class="mb-5">Découvrez la liste de nos voitures, trouvez celle qui satisfera vos besoins en termes de confort et de performance.</p>
                </div>
            </div>

            <!-- Formulaire de recherche -->
            <form class="input-group d-flex gap-2" method="get" action="voitures.php">
                <input type="text" class="form-control" name="search" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="basic-addon2" id="search" value="<?= htmlspecialchars($search) ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Rechercher</button>
                    <a href="voitures.php" class="btn btn-dark">Retour</a>
                </div>
            </form>

            <div class="voitures-container">
                <div class="row">
                    <?php if (count($voitures) > 0): ?>
                        <?php foreach ($voitures as $voiture): ?>
                            <div class="col-sm-6 col-md-4 mb-4">
                                <div class="card voiture-card wow fadeInUp" data-wow-delay="0.1s">
                                    <img src="https://supercardimitri.alwaysdata.net/Supercar/Supercar-admin/<?= htmlspecialchars(trim($voiture['car_image'])) ?>"
                                        class="card-img-top img-fluid"
                                        alt="<?= htmlspecialchars($voiture['car_name']) ?>">
                                    <div class="card-body">
                                        <p class="text-muted mb-1 text-start"><?= htmlspecialchars($voiture['car_status']) ?></p>
                                        <h5 class="card-title fw-bold"><?= htmlspecialchars($voiture['car_name']) ?></h5>
                                        <ul class="list-unstyled d-flex flex-wrap gap-2">
                                            <li class="d-flex align-items-center">
                                                <span class="material-symbols-outlined">auto_transmission</span> <?= htmlspecialchars($voiture['car_transmission']) ?>
                                            </li>
                                            <li class="d-flex align-items-center">
                                                <span class="material-symbols-outlined">local_gas_station</span> <?= htmlspecialchars($voiture['fuel_type']) ?>
                                            </li>
                                            <li class="d-flex align-items-center">
                                                <span class="material-symbols-outlined">calendar_month</span> <?= htmlspecialchars($voiture['year']) ?>
                                            </li>
                                            <li class="d-flex align-items-center">
                                                <span class="material-symbols-outlined">swap_driving_apps_wheel</span> <?= number_format($voiture['car_km'], 0, ',', ' ') ?> km
                                            </li>
                                        </ul>
                                        <div class="d-flex justify-content-between mt-3">
                                            <?php if ($voiture['car_status'] === 'Vendu'): ?>
                                                <span class="btn btn-dark" style="cursor: not-allowed;" disabled>Voiture indisponible</span>
                                            <?php else: ?>
                                                <a href="essai.php?car_name=<?= urlencode($voiture['car_name']) ?>" class="btn btn-danger">Demande d'essai</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <hr class="ligne-card">
                                    <div class="card-body d-flex justify-content-between align-items-center">
                                        <p class="fw-bold m-0"><?= number_format($voiture['car_price'], 2, ',', ' ') ?> MUR</p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Aucune voiture trouvée.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
</body>

</html>

<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-3 pb-2 mt-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="row justify-content-center">
        <div class="col-12 col-md-6 text-center">
            <!-- Copyright -->
            <p class="mb-2">&copy; 2025 <a class="border-bottom text-light" href="#">SuperCar</a>. Tous droits réservés.</p>

            <!-- Réseaux sociaux -->
            <div class="mb-2">
                <a href="https://www.facebook.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-facebook fa-lg"></i>
                </a>
                <a href="https://www.twitter.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-twitter fa-lg"></i>
                </a>
                <a href="https://www.instagram.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-instagram fa-lg"></i>
                </a>
                <a href="https://www.linkedin.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-linkedin fa-lg"></i>
                </a>
            </div>

            <!-- Mentions légales -->
            <div>
                <a href="#" class="text-light" data-bs-toggle="modal" data-bs-target="#mentionsModal">
                    <u>Mentions légales</u>
                </a>
            </div>
        </div>
    </div>

    <!-- Modal Mentions légales -->
    <div class="modal fade" id="mentionsModal" tabindex="-1" aria-labelledby="mentionsLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content text-dark">
                <div class="modal-header">
                    <h5 class="modal-title" id="mentionsLabel">Mentions légales</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Nom du site :</strong> Supercar</p>
                    <p><strong>URL :</strong> http://localhost/supercar</p>
                    <p><strong>Responsables du projet :</strong><br>
                        Karen Andriantasy & Dimitri MEYEPA<br>
                        Étudiants en BTS SIO – Réalisation Professionnelle<br>
                        MCCI Business School<br>
                        Rue Savoir, Cybercity, Ebene<br>
                        Email : info.supercar@gmail.com
                    </p>
                    <p><strong>Hébergement :</strong><br>
                        Site hébergé localement via MAMP dans le cadre d’un projet scolaire.</p>
                    <p><strong>Propriété intellectuelle :</strong><br>
                        Le contenu de ce site est protégé. Toute reproduction est interdite sans autorisation des auteurs.</p>
                    <p><strong>Données personnelles :</strong><br>
                        Aucune donnée personnelle n’est collectée sur ce site.</p>
                    <p><strong>Limitation de responsabilité :</strong><br>
                        Ce site est un prototype académique. Il ne représente pas une entreprise réelle.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->

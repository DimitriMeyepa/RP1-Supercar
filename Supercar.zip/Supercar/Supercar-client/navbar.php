<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('php/config.php');

// Récupérer toutes les infos sauf Email
$query = "SELECT type, icon_class, value FROM contact_info WHERE type != 'Email'";
$stmt = $pdo->prepare($query);
$stmt->execute();
$infos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>SuperCar</title>
    <style>
        html, body {
    overflow-x: hidden;
}

    @media (max-width: 991.98px) {
        .user-dropdown .btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.9rem;
        }
        .user-dropdown .dropdown-menu {
            left: 0 !important;
            
        }
    }
</style>


    <!-- Favicon -->
    <link href="assets/icon.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@600;700&family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">

    <!-- Icon Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-light p-0">
        <div class="row gx-0 d-none d-lg-flex">
            <div class="col-lg-7 px-5 text-start">
                <?php foreach ($infos as $info): ?>
                    <?php if (in_array($info['type'], ['Adresse', 'Heure'])): ?>
                        <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                            <small class="<?= $info['icon_class'] ?> me-2"></small>
                            <small><?= htmlspecialchars($info['value']) ?></small>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <div class="col-lg-5 px-5 text-end">
                <?php foreach ($infos as $info): ?>
                    <?php if ($info['type'] == 'Telephone'): ?>
                        <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                            <small class="<?= $info['icon_class'] ?> me-2"></small>
                            <small><?= htmlspecialchars($info['value']) ?></small>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <div class="h-100 d-inline-flex align-items-center">
                    <a class="btn btn-sm-square bg-white text-primary me-1" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-1" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-1" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-0" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="assets/logo1.png" alt="SuperCar" style="width: 10rem;">
    </a>
    <button class="navbar-toggler me-4" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.php" class="nav-item nav-link active">Accueil</a>
            <a href="voitures.php" class="nav-item nav-link">Voitures</a>
            <a href="service.php" class="nav-item nav-link">Services</a>
            <?php if (isset($_SESSION['client_id'])): ?>
                <a href="essai.php" class="nav-item nav-link">Essai Voitures</a>
            <?php else: ?>
                <a href="connexion.php" class="nav-item nav-link">Essai Voitures</a>
            <?php endif; ?>
            <a href="contact.php" class="nav-item nav-link">Contact</a>
        </div>

        <!-- Icône utilisateur -->
        <div class="dropdown me-3 my-2 my-lg-0">
            <a class="dropdown-toggle d-flex align-items-center py-2 px-3" href="#" role="button" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user fs-5 me-2" style="color: <?= isset($_SESSION['client_id']) ? 'red' : 'black' ?>;"></i>
                <span class="d-none d-lg-inline">
                    <?php if (isset($_SESSION['client_id'])): ?>
                        <?= htmlspecialchars($_SESSION['client_prenom'] . ' ' . $_SESSION['client_nom']) ?>
                    <?php else: ?>
                        Compte
                    <?php endif; ?>
                </span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-end " aria-labelledby="dropdownUser" style="z-index: 9999;">
                <?php if (isset($_SESSION['client_id'])): ?>
                    <li><a class="dropdown-item text-danger" href="deconnexion.php">Déconnexion</a></li>
                <?php else: ?>
                    <li><a class="dropdown-item" href="connexion.php">Se connecter</a></li>
                    <li><a class="dropdown-item" href="inscription.php">S'inscrire</a></li>
                <?php endif; ?>
            </ul>
        </div>

        

    </div>
</nav>

    <!-- Navbar End -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template JS -->
    <script src="js/main.js"></script>
</body>
</html>

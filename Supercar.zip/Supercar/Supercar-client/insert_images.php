<?php
// Inclure le fichier de connexion
require 'php/config.php';

// Définir le dossier contenant les images
$directory = 'assets/list';

// Vérifier si le dossier existe
if (!is_dir($directory)) {
    die("Le dossier $directory n'existe pas.");
}

// Récupérer les fichiers du dossier
$files = scandir($directory);

foreach ($files as $file) {
    // Ignorer les fichiers "." et ".."
    if ($file === '.' || $file === '..') {
        continue;
    }

    $filePath = $directory . '/' . $file;

    // Lire le fichier en binaire
    $imageData = file_get_contents($filePath);

    // Préparer la requête SQL
    $sql = "INSERT INTO images (image_name, image_data) VALUES (:image_name, :image_data)";
    $stmt = $pdo->prepare($sql);

    // Exécuter la requête avec les paramètres
    try {
        $stmt->execute([
            ':image_name' => $file,
            ':image_data' => $imageData
        ]);
        echo "Image $file insérée avec succès.<br>";
    } catch (PDOException $e) {
        echo "Erreur lors de l'insertion de $file : " . $e->getMessage() . "<br>";
    }
}

// Fermeture de la connexion (facultatif car PDO se ferme automatiquement)
$pdo = null;
?>

<?php
include('php/config.php');

// Vérifie si un terme de recherche est passé dans l'URL
if (isset($_GET['search'])) {
  $search = $_GET['search'];

  // Préparer la requête avec PDO pour récupérer uniquement les voitures dont le nom contient le terme recherché
  $sql = "SELECT * FROM voitures WHERE LOWER(car_name) LIKE LOWER(:searchTerm)";
  $stmt = $pdo->prepare($sql);
  $searchTerm = "%" . $search . "%"; // Ajoute les pourcentages pour la recherche LIKE
  $stmt->bindParam(':searchTerm', $searchTerm, PDO::PARAM_STR);
  $stmt->execute();

  // Si des résultats sont trouvés
  if ($stmt->rowCount() > 0) {
    // Afficher les résultats sous forme de grille
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      // Affichage des informations de la voiture
      echo '<div class="col-md-4 mb-4">';
      echo '<div class="card wow fadeInUp" data-wow-delay="0.2s">';
      echo '<img src="' . htmlspecialchars($row['car_image']) . '" class="card-img-top img-fluid" alt="' . htmlspecialchars($row['car_name']) . ' Image">';
      echo '<div class="card-body">';
      echo '<p class="text-muted mb-1 text-start">' . htmlspecialchars($row['car_status']) . '</p>';
      echo '<h5 class="card-title fw-bold">' . htmlspecialchars($row['car_name']) . '</h5>';
      echo '<ul class="list-unstyled d-flex flex-wrap gap-2">';
      echo '<li class="d-flex align-items-center"><span class="material-symbols-outlined">auto_transmission</span> ' . htmlspecialchars($row['car_transmission']) . '</li>';
      echo '<li class="d-flex align-items-center"><span class="material-symbols-outlined">local_gas_station</span> ' . htmlspecialchars($row['fuel_type']) . '</li>';
      echo '<li class="d-flex align-items-center"><span class="material-symbols-outlined">calendar_month</span> ' . htmlspecialchars($row['year']) . '</li>';
      echo '<li class="d-flex align-items-center"><span class="material-symbols-outlined">swap_driving_apps_wheel</span> ' . number_format($row['car_km'], 0, ',', ' ') . ' km</li>';
      echo '</ul>';
      echo '<div class="d-flex justify-content-between mt-3">';
      echo '<a href="essai.php?id=' . $row['id'] . '" class="btn btn-primary">Demande d\'essai</a>';
      echo '</div>';
      echo '</div>';
      echo '<hr class="ligne-card">';
      echo '<div class="card-body d-flex justify-content-between align-items-center">';
      echo '<p class="fw-bold m-0">' . number_format($row['car_price'], 2, ',', ' ') . ' MUR</p>';
      echo '</div>';
      echo '</div>';
      echo '</div>';
    }
  } else {
    // Aucune voiture ne correspond à la recherche
    echo "<p class='text-center'>Aucune voiture trouvée.</p>";
  }
} else {
  // Si aucun terme de recherche n'est passé, afficher toutes les voitures
  $sql = "SELECT * FROM voitures";
  $stmt = $pdo->prepare($sql);
  $stmt->execute();
}
?>

<?php 
include('navbar.php');
include('php/config.php');

$success_message = '';
$error_message = '';

// Fonction pour récupérer l'information de contact par type
function get_contact_info($type, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM contact_info WHERE type = :type");
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
}

// Récupérer les informations de contact
$adresse = get_contact_info('Adresse', $pdo);
$contact_email = get_contact_info('Email', $pdo);
$contact_telephone = get_contact_info('Telephone', $pdo);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $form_email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $message = $_POST['message'];

    $query = "INSERT INTO contact_messages (nom, email, telephone, message) 
              VALUES (:nom, :email, :telephone, :message)";

    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':nom', $nom);
    $stmt->bindParam(':email', $form_email);
    $stmt->bindParam(':telephone', $telephone);
    $stmt->bindParam(':message', $message);

    if ($stmt->execute()) {
        $success_message = "Message envoyé avec succès.";
    } else {
        $error_message = "Une erreur est survenue, veuillez réessayer.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Supercar</title>
</head>
<body>

<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Contact</h1>
        </div>
    </div>
</div>
<!-- Page Header End -->

<!-- Contact Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h1 class="mb-5">Contactez-nous pour toutes demandes</h1>
        </div>
        <div class="row g-4">
            <div class="col-12">
                <div class="row gy-4">
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">Adresse</h5>
                            <p class="m-0">
                                <?php if ($adresse): ?>
                                    <i class="<?php echo $adresse['icon_class']; ?>"></i>
                                    <?php echo $adresse['value']; ?>
                                <?php else: ?>
                                    <span>Adresse non disponible</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">Email</h5>
                            <p class="m-0">
                                <?php if ($contact_email): ?>
                                    <i class="<?php echo $contact_email['icon_class']; ?>"></i>
                                    <?php echo $contact_email['value']; ?>
                                <?php else: ?>
                                    <span>Email non disponible</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">Téléphone</h5>
                            <p class="m-0">
                                <?php if ($contact_telephone): ?>
                                    <i class="<?php echo $contact_telephone['icon_class']; ?>"></i>
                                    <?php echo $contact_telephone['value']; ?>
                                <?php else: ?>
                                    <span>Téléphone non disponible</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
                <!-- Carte -->
                <?php
                $map_config = $pdo->query("SELECT * FROM map_config WHERE id = 1")->fetch();
                $map_iframe = $map_config['iframe_link'] ?? '';
                ?>
                <?php if ($map_iframe): ?>
                    <iframe class="position-relative rounded w-100 h-100"
                            src="<?php echo $map_iframe; ?>" frameborder="0" style="min-height: 350px; border:0;" allowfullscreen=""
                            aria-hidden="false" tabindex="0"></iframe>
                <?php else: ?>
                    <p>Carte non disponible</p>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <p class="mb-4">Nous sommes là pour répondre à toutes vos questions concernant nos véhicules, nos services et vos besoins en matière d'automobile. N'hésitez pas à nous contacter !</p>
                    <form action="" method="post">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="nom" placeholder="Nom" required>
                                    <label for="name">Nom</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" name="email" placeholder="Email" required>
                                    <label for="email">Email</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="telephone" placeholder="Numéro de téléphone">
                                    <label for="subject">Numéro de téléphone</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a message here" name="message" style="height: 100px"></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Envoyer</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->

<!-- Toast Container -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1055">
    <div id="customToast" class="toast align-items-center text-bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="toastMessage">
                <!-- Message injecté dynamiquement -->
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<?php if ($success_message || $error_message): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var toastEl = document.getElementById('customToast');
        var toastMessage = document.getElementById('toastMessage');

        <?php if ($success_message): ?>
            toastMessage.textContent = "<?php echo $success_message; ?>";
            toastEl.classList.remove('text-bg-danger');
            toastEl.classList.add('text-bg-success');
        <?php elseif ($error_message): ?>
            toastMessage.textContent = "<?php echo $error_message; ?>";
            toastEl.classList.remove('text-bg-success');
            toastEl.classList.add('text-bg-danger');
        <?php endif; ?>

        var toast = new bootstrap.Toast(toastEl);
        toast.show();
    });
</script>
<?php endif; ?>

<?php include('footer.php'); ?>

</body>
</html>
